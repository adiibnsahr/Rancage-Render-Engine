#include "../Core/include/Math/Vector3.h"

namespace Math
{
    // Operator implementations already in header for simplicity
}