#include "../Core/include/Math/MathUtils.h"

namespace Math
{
    // Kosong dulu
}