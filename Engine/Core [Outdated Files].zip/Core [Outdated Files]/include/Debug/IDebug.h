/**
 * @file IDebug.h
 * @brief Antarmuka untuk sistem debugging DirectX 12.
 * @author [Nama Anda]
 * @date 18 April 2025
 */

 #pragma once
 #include "../Logger/ILogger.h"
 
 namespace Debug {
 
 /**
  * @class IDebug
  * @brief Antarmuka untuk fungsi debugging DirectX 12.
  */
 class IDebug {
 public:
     virtual ~IDebug() = default;
 
     /**
      * @brief Menginisialisasi lapisan debug DirectX 12.
      * @return True jika berhasil, false jika gagal.
      */
     virtual bool initialize() = 0;
 
     /**
      * @brief Mengatur antrian informasi untuk menangkap pesan debug.
      */
     virtual void setupInfoQueue() = 0;
 };
 
 } // namespace Debug