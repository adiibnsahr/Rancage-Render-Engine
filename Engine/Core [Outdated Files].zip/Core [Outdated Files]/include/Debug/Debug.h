/**
 * @file DebugImpl.h
 * @brief Deklarasi kelas DebugImpl untuk implementasi debugging DirectX 12.
 * @author [Nama Anda]
 * @date 18 April 2025
 */

 #pragma once
 #include "IDebug.h"
 #include "ILogger.h"
 #include <memory>
 
 namespace Debug {
 
 /**
  * @class DebugImpl
  * @brief Implementasi konkret dari IDebug untuk debugging DirectX 12.
  */
 class DebugImpl : public IDebug {
 public:
     /**
      * @brief Konstruktor dengan injeksi pencatat log.
      * @param logger Pointer ke objek ILogger (bisa sinkronus atau asinkronus).
      */
     explicit DebugImpl(std::shared_ptr<Logger::ILogger> logger);
     ~DebugImpl() override = default;
 
     bool initialize() override;
     void setupInfoQueue() override;
 
 private:
     std::shared_ptr<Logger::ILogger> m_logger; ///< Pencatat log yang digunakan.
 };
 
 } // namespace Debug