#pragma once

namespace Math
{
    // Tambah util nanti (misal lerp, clamp)
}
